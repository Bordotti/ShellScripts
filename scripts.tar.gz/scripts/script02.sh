#segundo script
clear
echo "digite seu nome"
read nome
echo "Ola $nome"
echo 'ola $nome'
exit 0
