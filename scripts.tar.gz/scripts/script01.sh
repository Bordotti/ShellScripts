#Meu primeiro script!
clear
echo "knowlegde is power"
exit 0
